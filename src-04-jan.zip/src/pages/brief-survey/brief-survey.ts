import  { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NetworkProvider } from '../../providers/network/network';
import { HttpServiceProvider } from '../../providers/http-service/http-service';
import { CommonProvider } from '../../providers/common/common';
import { CONFIG } from '../../config/config';
import { WelcomePage } from "../welcome/welcome";

@Component({
  selector: 'page-brief-survey',
  templateUrl: 'brief-survey.html',
})
export class BriefSurveyPage {
  briffSurveyForm: FormGroup;
  submitAttempt: boolean;
  constructor(
    public navCtrl: NavController,
    public formBuilder: FormBuilder,
    public networkPro: NetworkProvider,
    public httpService: HttpServiceProvider,
    public common: CommonProvider
  ) {
    this.submitAttempt = false;
    this.briffSurveyForm = formBuilder.group({
      customer_name: ['', Validators.compose([
        Validators.maxLength(100),
        Validators.pattern(CONFIG.ValidExpr.lastname),
        Validators.required])
      ],
      institution: ['', Validators.compose([Validators.required])],
      city: ['', Validators.compose([Validators.required])],
      state: ['', Validators.compose([Validators.required])],
      diff_btw_therapy_nd_immuno: [false],
      perform: [false],
      asked_price_individually: [false],
      asked_price_combine: [false],
      insurance_coverage: [false],
      insurance_coverage_notes: [""],
      provided_feedback: [false],
      provided_feedback_notes: [""],
      clinic_trial_interess: [false],
      clinic_trial_interess_notes: [""],
      ruleout_report_chemotherapy: [false],
      ruleout_report_chemotherapy_notes: [""],
      ruleout_report_radiation: [false],
      ruleout_report_radiation_notes: [""],
      compared_test_to_competitors: [false],
      Competitor: [""],
      compared_test_to_competitors_notes: [""],
    });
  }

  public submitSurvey(){
    this.submitAttempt = true;
    if (this.briffSurveyForm.valid) {
      if(this.briffSurveyForm.value.insurance_coverage) {
        if(!this.briffSurveyForm.value.insurance_coverage_notes) {
          return false;
        }
      }
      if(this.briffSurveyForm.value.provided_feedback) {
        if(!this.briffSurveyForm.value.provided_feedback_notes) {
          return false;
        }
      }
      if(this.briffSurveyForm.value.clinic_trial_interess) {
        if(!this.briffSurveyForm.value.clinic_trial_interess_notes) {
          return false;
        }
      }
      if(this.briffSurveyForm.value.ruleout_report_chemotherapy) {
        if(!this.briffSurveyForm.value.ruleout_report_chemotherapy_notes) {
          return false;
        }
      }
      if(this.briffSurveyForm.value.ruleout_report_radiation) {
        if(!this.briffSurveyForm.value.ruleout_report_radiation_notes) {
          return false;
        }
      }
      if(this.briffSurveyForm.value.compared_test_to_competitors) {
        if(!this.briffSurveyForm.value.Competitor) {
          return false;
        }
        if(!this.briffSurveyForm.value.compared_test_to_competitors_notes) {
          return false;
        }
      }
      if (this.networkPro.checkNetwork() == true) {
        this.common.presentLoading();
        this.httpService.postData("survey/add", this.briffSurveyForm.value).subscribe(data => {
          this.common.dismissLoading();
          if (data.status == 200) {
            this.common.showToast(data.message);
            this.navCtrl.setRoot(WelcomePage);
          } else {
            this.common.showToast(data.message);
          }
        }, error => {
          console.log("Error=> ", error);
          this.common.dismissLoading();
        });
      }
    }
  }

}
