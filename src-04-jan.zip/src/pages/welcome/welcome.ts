import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { HomePage } from '../home/home'
import { ComprehensivePage } from '../comprehensive/comprehensive';
import { BriefSurveyPage } from '../brief-survey/brief-survey';

@Component({
  selector: 'page-welcome',
  templateUrl: 'welcome.html',
})
export class WelcomePage {

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams
  ) {
  }

  /**Function created for redirect on home page
   * Created: 03-Jan-2018
   * Created By: Jagdish Thakre
   */
  public goToHome() {
    this.navCtrl.setRoot(HomePage);
  }

  /**Function created for redirect on home page
   * Created: 03-Jan-2018
   * Created By: Jagdish Thakre
   */
  public goToCallBrief() {
    this.navCtrl.push(BriefSurveyPage);
  }

}
