import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CancertypePage } from './cancertype';

@NgModule({
  declarations: [
    CancertypePage,
  ],
  imports: [
    IonicPageModule.forChild(CancertypePage),
  ],
})
export class CancertypePageModule {}
