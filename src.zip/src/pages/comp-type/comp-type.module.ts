import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CompTypePage } from './comp-type';

@NgModule({
  declarations: [
    CompTypePage,
  ],
  imports: [
    IonicPageModule.forChild(CompTypePage),
  ],
})
export class CompTypePageModule {}
